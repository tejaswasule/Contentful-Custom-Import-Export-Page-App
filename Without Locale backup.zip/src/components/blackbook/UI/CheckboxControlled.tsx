import { Checkbox } from "@contentful/f36-components";
import { useEffect, useState } from "react";

export default function CheckboxControlled(props:any) {
  const [checkboxState, setCheckboxState] = useState(true);
  

  const checkboxHandler = (event:Event) =>{
    setCheckboxState(event?.target?.checked);
  }

  return (
    <Checkbox
      {...props}
      
      onChange={checkboxHandler}
      isChecked={checkboxState}
      value={checkboxState?"true":"false"}
    >
      
    </Checkbox>
  );
}