const getCSVFile = async function (data:any, contentType:string , selectString:string) {
  console.log(data);
  const csvdata = csvmaker(data,selectString,contentType);
  download(csvdata, contentType);
};
function arrToObj(arr:Array<string>){ //converting function
  let obj={}
  for(let i=0;i<arr.length;i++){
    obj[arr[i]]={"en-US":''}  
  }
  return obj
}

const csvmaker = function (data:any,selectString:string,contentType:string) {
  // Empty array for storing the values
  console.log(data)
  let csvRows = [];

  // Headers is basically a keys of an
  // object which is id, name, and
  // profession

  const headers = Object.keys(data[0]);

  // As for making csv format, headers
  // must be separated by comma and
  // pushing it into array


  
  //csvRows.push(headers.join(","));

  const headersSelectSTring = contentType+","+selectString.replaceAll("fields.",'');
  console.log(headersSelectSTring);

  csvRows.push(headersSelectSTring);
  const sampleRowObject = arrToObj(headersSelectSTring.split(","));
  console.log(sampleRowObject)
  // Pushing Object values into array
  // with comma separation
  let values:string;

  const modifiedData = data.map((item:any)=>{
    return {...sampleRowObject,...item};
  });
  
  modifiedData.map((item:any) => {
    Object.values(item).map((entry:any) => {
      
      if (values === undefined) {
        values = entry["en-US"] + ",";
      } else {
        values = values + entry["en-US"] + ",";
      }
      return null;
    });
    csvRows.push(values);
    values = undefined;
  });

  // Returning the array joining with new line
  return csvRows.join("\n");
};

const download = function (data:any, contentType:string) {
  const blob = new Blob([data], { type: "text/csv" });
  const url = window.URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.setAttribute("href", url);
  a.setAttribute("target","_blank")
  a.setAttribute(
    "download",
    contentType + "-" + new Date().toString() + ".csv"
  );
  a.click();
};
export { getCSVFile };
