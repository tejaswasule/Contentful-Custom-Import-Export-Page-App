import React, { useEffect, useState } from 'react';
import { useCMA } from '@contentful/react-apps-toolkit';
import { ContentTypeProps } from 'contentful-management';

import { Route, BrowserRouter, Routes } from 'react-router-dom';
import { Heading, Box } from '@contentful/f36-components';

import { PageLayout } from '../components/PageLayout';
import Dashboard from '../page/Dashboard';
import Export from '../page/Export';
import Import from '../page/Import';

function NotFound() {
  return <Heading>404</Heading>;
}

export const PageRouter = () => {
  return (
    <BrowserRouter>
      <Page />
    </BrowserRouter>
  );
};

const Page = () => {
  const cma = useCMA();
  const [contentTypes, setContentTypes] = useState<ContentTypeProps[]>([]);

  useEffect(() => {
    cma.contentType.getMany({}).then((result) => result?.items && setContentTypes(result.items));
  }, []);

  return (
    <Box marginTop="spacingXl" className="page">
      <Routes>
        <Route path="/" element={<PageLayout />}>
          <Route index element={<Dashboard contentTypes={contentTypes} />} />
          <Route path="export" element={<Export  />} />
          <Route path="import" element={<Import/>} />
          <Route path="*" element={<NotFound />} />
        </Route>
      </Routes>
    </Box>
  );
};
