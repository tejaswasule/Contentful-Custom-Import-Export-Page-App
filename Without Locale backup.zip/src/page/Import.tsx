
import { Box, Button, Paragraph, TextInput,Notification, Stack, Note } from "@contentful/f36-components";
import { Fragment, useEffect, useState } from "react";
import { useCMA, useSDK } from '@contentful/react-apps-toolkit';
import { WorkflowsIcon} from '@contentful/f36-icons';
import _ from "lodash";

export default function Import (){

    const [selectedFile, setSelectedFile] = useState(null);

    const [rowCount, setRowCount] = useState(0);

	const [isSelected, setIsSelected] = useState(false);

    const [massage,setMassage] = useState('');

    const [isLoading,setIsLoading] = useState(false);

    const [inValidEntries,setInValidEntries] = useState([]);

    const [contentTypeRead,setContentTypeRead] = useState([]);

    const cma= useCMA();
    const transformValueFromCsv = (value) =>{
        if(value){
            
            if(value==="\r" || value ==='\r' ){
                return false;
            }
            if(!Number.isNaN(Number(value))){
                return Number(value);
            }else if(value.toLowerCase()==='true' || value.toLowerCase()==='true\r'){
                return true;
            }else if(value.toLowerCase()==='false' || value.toLowerCase()==='false\r'){
                return false;
            }else{
                return value.toString();
            }
        }
      } 
    
    useEffect(()=>{
        console.log("Updated rowCount-->"+rowCount);

    },[rowCount])
	const changeHandler = (event:Event) => {
		if(event?.target?.files[0]){
            setSelectedFile(event?.target?.files[0]);
             setIsSelected(true);
             setMassage('');
             setIsLoading(false)
        }else{
            setSelectedFile(null);
		    setIsSelected(false);
            setMassage('')
            setIsLoading(false)
        }
        
	};
     function csvToJSON(csv:any) {
        var lines = csv.split('\n');
        var result = [];
        var headers;
        headers = lines[0].split(",");
        const contentTypeRead = headers[0];
        setContentTypeRead(headers[0]);
        const selectFieldAttribute = lines[0].split(",");
        const selectStringArray = selectFieldAttribute.filter((item:string,index:Number)=>{
            if(index!=0){
                return item;
            }
        }).map((item:string,index:Number)=>{
            return "fields."+item;  
      });
      const selectString = selectStringArray.toString().trim();
        for (var i = 1; i < lines.length; i++) {
          var obj = {};
          if (lines[i] == undefined || lines[i].trim() == "") {
            continue;
          }
          var words = lines[i].split(",");
          console.log(words);
          for (var j = 0; j < words.length; j++) {
            if(headers[j]!=undefined){
                obj[headers[j].trim()] = { "en-US": transformValueFromCsv(words[j])} 
            }
        }
        console.dir(obj)
        result.push(obj);
      }
      console.log(result)
      updateEntries(result,contentTypeRead,selectString);
    }
  const validateEntry = (entry:any,validations:Array<any>) =>{
    let isValid = true;
    for(var propertyName in entry) {
        for(var validationPropertyName in validations) {
            if(validations[validationPropertyName].id===propertyName){       
                if(validateField(validations[validationPropertyName].type,validations[validationPropertyName].required,entry[propertyName]["en-US"])){
                    //console.log("valid field--> "+JSON.stringify(propertyName));
                }else{
                    //console.log("invalid field--> "+JSON.stringify(propertyName));
                    isValid=false;
                    return {isValid,validationPropertyName:propertyName};
                }
            }
        }  
     }
     return {isValid,validationPropertyName:''};
    }  
    const hasUniqueEntryIDs = (csvEntries:Array<any>,contentTypeRead:string,validations:Array<any>) =>{
       //console.log(validations);
       const uniqueAttributes:Array<any>= [];
       validations.forEach((item:any,index:number)=>{
        item?.validations?.forEach((itemV:any,indexV:number)=>{
            if(itemV.hasOwnProperty('unique') && itemV?.unique){
                uniqueAttributes.push(item.id);
            }
        })
       });
       if(uniqueAttributes.length===0){
        return true
        }else{
            const set = new Set();
       console.log(uniqueAttributes);
       let returnValue = true;
       uniqueAttributes.forEach((uAttr)=>{
            set.clear();
            return csvEntries.concat().forEach((entry)=>{
                
                if(!set.has(entry[uAttr]["en-US"])){
                    console.error("NOT DUPLICATE ID");
                    set.add(entry[uAttr]["en-US"])
                }else{
                    console.log(set)
                    console.error("DUPLICATE ID ATTRIBUTE -->"+uAttr+" Duplicate ID--->"+entry[uAttr]["en-US"]);
                    setInValidEntries((prev)=>{
                        return [
                            ...prev,
                            {
                                invalidField:uAttr,
                                id:entry[contentTypeRead]["en-US"]
                            }

                        ]
                    })
                    returnValue = false;
                    return returnValue;
                }   
            });
       });
        
       return returnValue;
        }

       
    }
    const validateEntries = (csvEntries:Array<any>,contentTypeRead:string,validations:Array<any>) =>{
    let returnValue = true;
    csvEntries.map((entry)=>{
        //validateEntry(entry,validations); 
        const obj = validateEntry(entry,validations);
        if(!obj.isValid){
            setInValidEntries((prevState)=>{
                return [
                    ...prevState,
                    {
                        invalidField:obj?.validationPropertyName,
                        id:entry[contentTypeRead]['en-US']
                    }
                ]
            });
            returnValue = false;
        }
        //console.log("-----------------------");  
    })
    return returnValue;
  }
  const checkNull = (required:boolean,value:string) =>{
    
    if((value === undefined || value?.trim()=== '' || value?.trim()=== "") && required===true){
        return false;
    }else{
        return true;
    }
  }

  const validateField = (type:string,required:boolean,value:string | Number | boolean) =>{

    switch (type) {
        case "Symbol":
            return checkNull(required,value?.toString());
            break;
        case "Integer":
            if(required){
                return Number.isInteger(value) && value!=0;
            }else{
                if(value===undefined || (Number.isInteger(value) && value!=0)){
                    return true;
                }else{
                    return false;
                }
            }
            
        break; 
        case "Date":
            return true;
        break;    
        break;
        case "Boolean":
            console.log(value);
            if(required){
                return typeof value === "boolean";
            }else{
                if(typeof value === "boolean" || value===0){
                    return true;
                }else{
                    return false;
                }
            }
            
        break;

        default:
            break;
    }
  }  
   async function updateEntries(result:any,contentTypeRead:string,selectString:string) {
    const removableAttribute = contentTypeRead;
    let validations;
    
    const validationsResponse = await cma.contentType.get({contentTypeId:contentTypeRead})
    validations=validationsResponse.fields;
    
    console.log(validationsResponse.fields);
    /*
    cma.contentType.get({contentTypeId:contentTypeRead}).then((types) => {   
        validations = types.fields; 
        
    });*/

    if(validateEntries(result.concat(),contentTypeRead,validations) && hasUniqueEntryIDs(result.concat(),contentTypeRead,validations)){
        
        result.map((csvEntry:any) => {
        const entryIDx = csvEntry[contentTypeRead]['en-US'];
        console.log("entryIDx-->"+entryIDx);
        
        cma.entry.getMany({query:{"sys.id":entryIDx,content_type:contentTypeRead,select:selectString,limit: 1,}}).then((entries)=>{
                const cmaEntry = entries?.items[0];
                console.log(entries);
                delete csvEntry[removableAttribute];
                console.log(csvEntry);
                console.log(cmaEntry.fields);
                if(!_.isMatch(csvEntry,cmaEntry.fields)){
                    try{
                        cmaEntry.fields={...cmaEntry.fields,...csvEntry}//setting cvs values to CMA Entry
                        console.log("Inside IF")
                        
                        if(entryIDx===undefined){
                            
                            cma.entry.create({contentTypeId:contentTypeRead},cmaEntry).then((cmaEntryPublish)=>{
                                console.log(cmaEntryPublish)
                                cma.entry.publish({entryId:cmaEntryPublish.sys.id},cmaEntryPublish).then((cmaEntryPublished)=>{
                                    console.log("cmaEntryPublished"+cmaEntryPublished);
                                    setRowCount(prevState => prevState + 1);
                                });
                            });
                        }else{
                            cma.entry.update({entryId:entryIDx},cmaEntry).then((cmaEntryPublish)=>{
                                cma.entry.publish({entryId:entryIDx},cmaEntryPublish).then((cmaEntryPublished)=>{
                                    console.log("cmaEntryPublished"+cmaEntryPublished);
                                    setRowCount(prevState => prevState + 1);
                                });
                            });
                        }
                        
                    }catch(error){
                        console.log(error);
                    } 
                }else{
                    console.log("No Updates required entry ID"+entryIDx);
                }
            });
            
        });
        setMassage("File imported successfully, Rows affected are ");
        setIsSelected(false);
        setSelectedFile(null);
        setIsLoading(false);
    }else{
        //setMassage("Validation erros found in file");
        setIsSelected(false);
        setSelectedFile(null);
        setIsLoading(false);    
    }    
    
    }
 
	const handleSubmission = () => {
        setIsLoading(true);
        setRowCount(0);
        setInValidEntries((prevState)=>{
            return [];
        })
        const file = selectedFile;

        if(file!=undefined){

            const reader = new FileReader();
            reader.readAsText(file);
            reader.onload = function (event) {
            var csv = event.target.result;
            csvToJSON(csv); 
        };
        }
    };

    
    return (<Box marginTop="spacingM">
            <TextInput accept=".csv" type="file" name="file" onChange={changeHandler} />
			<div>
				<Button startIcon={<WorkflowsIcon variant="muted" />}  style={{margin:"10px"}} isDisabled = {!isSelected} variant="primary" onClick={handleSubmission}>{isLoading?"Importing":"Import"}</Button>
			</div>
            {inValidEntries.length===0 && massage!=''?<Stack flexDirection="column">
                <Note variant="positive">{massage}{rowCount}</Note>
            </Stack>:""}

            {inValidEntries.length>=1?<Stack flexDirection="column">
                <Note variant="negative">
                    <Paragraph>Error in Entries imported from file,Rows affected 0</Paragraph>
                    <Paragraph>Please find below details for invalid entry</Paragraph>
                    {inValidEntries.map((entry,index)=>{
                        
                        return <Paragraph key={Math.random()}>
                            {entry?.id} {entry?.invalidField}
                        </Paragraph>
                    })}  
                </Note>
            </Stack>:""}

            </Box>)
}
