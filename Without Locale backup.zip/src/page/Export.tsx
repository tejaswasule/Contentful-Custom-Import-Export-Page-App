import React, { useEffect, useState } from 'react';
import { Box, Paragraph,Accordion,Text } from '@contentful/f36-components';
import BlackBookTable from "../components/blackbook/UI/BlackBookTable";
import { useCMA } from '@contentful/react-apps-toolkit';
import Loader from "../components/blackbook/UI/Loader";

export default function Export() {
  const [contentTypes, setContentTypes] = useState<any[] | null>(null);

  const cma = useCMA();
  useEffect(() => {
    console.log("useEffect main Effect");
    async function getAllContentTypes() {

      const entries = await cma.contentType
        .getMany({})
        .then((entries) => {
          setContentTypes(entries.items);
        })
        .catch(() => []);
    }
    getAllContentTypes();
  }, []);

  return (
    <Box marginTop="spacingXl">
      <Paragraph>Please select Content Type to export </Paragraph>
      <Accordion>
        {!contentTypes? 
        <Loader/>:contentTypes.map((c_type,index)=>{
          
          return <Accordion.Item key={index+Math.random()} title={c_type.name}>
            
          <Text>
            <BlackBookTable contentTypeID={c_type?.sys?.id} contentType={c_type.fields}/>
          </Text>
      </Accordion.Item>
      })}
    </Accordion>
    </Box>
  );
}
